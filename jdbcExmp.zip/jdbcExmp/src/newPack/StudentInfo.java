package newPack;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class StudentInfo
{
	void addStudent() throws Exception
	{
		try
		{
			Class.forName("org.h2.driver");
			Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/jdbc:h2:~/test","sa"," ");
			PreparedStatement pst = con.prepareStatement("insert into student values(201,'rahul','mvm',98809446743)");
				pst.executeUpdate();
				pst.close();
				con.close();
				System.out.println("data is added...");
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
	


	public static void main(String[] args)throws Exception
	{
		StudentInfo studentInfo = new StudentInfo();
		studentInfo.addStudent();

	}

}
